NOTE : 

Tugas ini dibuat untuk memenuhi tugas UTS dari mata kuliah pemrograman internet.
atas nama saya : 
nama 		: Arya Danu Prasetya
nim		: 2302011004
prodi		: Teknik Informatika
semester	: 5 (Ganjil)

Yang mana tugas ini di buat oleh saya sendiri, dan sedikit bantuan dari chatgpt di bagian menjumlahkan sks, dan beberapa perbaikan supaya tugas ini terlihat lebih menarik.

Sekian note ini saya buat, lebih dan kurang saya mohon maaf.


follow : https://t.me/ryuustuff
-ryuu